"""Shared API dependencies — load the model bundle once and reuse it."""
from __future__ import annotations

from src.models.predict import load_bundle


def get_bundle():
    """FastAPI dependency returning the cached model bundle."""
    return load_bundle()


def model_is_ready() -> bool:
    try:
        load_bundle()
        return True
    except FileNotFoundError:
        return False
