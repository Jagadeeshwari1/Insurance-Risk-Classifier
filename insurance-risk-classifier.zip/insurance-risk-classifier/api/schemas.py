"""Pydantic schemas for the prediction API (request validation + responses)."""
from __future__ import annotations

from typing import Literal, Optional

from pydantic import BaseModel, Field


class ApplicantFeatures(BaseModel):
    """One applicant. Field constraints mirror src/data/validation.py.

    ``sex`` is accepted for audit logging and fairness monitoring but is NOT
    used as a model input.
    """

    age: int = Field(..., ge=18, le=100, examples=[45])
    annual_income: float = Field(..., ge=0, le=2_000_000, examples=[68000])
    bmi: float = Field(..., ge=10, le=70, examples=[27.4])
    num_dependents: int = Field(..., ge=0, le=20, examples=[1])
    prior_claims_count: int = Field(..., ge=0, le=50, examples=[0])
    years_as_customer: float = Field(..., ge=0, le=60, examples=[3.5])
    credit_score: int = Field(..., ge=300, le=850, examples=[710])
    chronic_conditions: int = Field(..., ge=0, le=20, examples=[0])
    smoker: Literal["yes", "no"]
    region: Literal["northeast", "southeast", "midwest", "west"]
    occupation_risk: Literal["low", "medium", "high"]
    exercise_frequency: Literal["never", "occasional", "regular"]
    sex: Optional[Literal["male", "female", "other"]] = Field(
        default=None, description="For audit/fairness logging only; not a model input."
    )


class Factor(BaseModel):
    feature: str
    value: object | None
    contribution: float
    direction: Literal["increases_risk", "decreases_risk"]


class PredictionResponse(BaseModel):
    probability: float = Field(..., description="Calibrated P(claim).")
    risk_tier: Literal["low", "medium", "high"]
    flagged_high_risk: bool
    decision_threshold: float
    model_version: Optional[str]
    top_factors: list[Factor] = []


class BatchRequest(BaseModel):
    applicants: list[ApplicantFeatures]
    explain: bool = False


class ModelInfo(BaseModel):
    version: Optional[str]
    backend: Optional[str]
    feature_columns: list[str]
    risk_tiers: dict
    decision_threshold: float
