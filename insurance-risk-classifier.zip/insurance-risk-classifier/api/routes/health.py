"""Health and model-metadata endpoints."""
from __future__ import annotations

from fastapi import APIRouter, Depends

from api.dependencies import get_bundle, model_is_ready
from api.schemas import ModelInfo

router = APIRouter(tags=["system"])


@router.get("/health")
def health() -> dict:
    """Liveness + model readiness."""
    return {"status": "ok", "model_loaded": model_is_ready()}


@router.get("/model-info", response_model=ModelInfo)
def model_info(bundle=Depends(get_bundle)) -> ModelInfo:
    return ModelInfo(
        version=bundle.get("version"),
        backend=bundle.get("backend"),
        feature_columns=bundle["feature_columns"],
        risk_tiers=bundle["risk_tiers"],
        decision_threshold=bundle["decision_threshold"],
    )
