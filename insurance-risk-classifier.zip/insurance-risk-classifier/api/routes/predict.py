"""Prediction endpoints (single + batch) with an audit log hook."""
from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException

from api.dependencies import get_bundle
from api.schemas import (
    ApplicantFeatures,
    BatchRequest,
    PredictionResponse,
)
from src.models.predict import predict_one
from src.utils.logging import get_logger

router = APIRouter(tags=["predictions"])
logger = get_logger("api.predict")


def _audit(payload: dict, result: dict) -> None:
    """Append-only audit hook. Insurance decisions must be reproducible later.

    In production this writes to a database / append-only store. Here it logs.
    """
    logger.info(
        "AUDIT version=%s tier=%s prob=%.4f flagged=%s",
        result.get("model_version"),
        result["risk_tier"],
        result["probability"],
        result["flagged_high_risk"],
    )


@router.post("/predict", response_model=PredictionResponse)
def predict(applicant: ApplicantFeatures, bundle=Depends(get_bundle)) -> dict:
    payload = applicant.model_dump()
    try:
        result = predict_one(payload, explain=True, bundle=bundle)
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc
    _audit(payload, result)
    return result


@router.post("/predict/batch", response_model=list[PredictionResponse])
def predict_batch(req: BatchRequest, bundle=Depends(get_bundle)) -> list[dict]:
    results = []
    for applicant in req.applicants:
        payload = applicant.model_dump()
        try:
            result = predict_one(payload, explain=req.explain, bundle=bundle)
        except ValueError as exc:
            raise HTTPException(status_code=422, detail=str(exc)) from exc
        _audit(payload, result)
        results.append(result)
    return results
