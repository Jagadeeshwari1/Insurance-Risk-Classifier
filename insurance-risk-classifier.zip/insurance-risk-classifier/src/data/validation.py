"""Input data validation.

Uses Pandera schemas when installed (recommended for production), and falls
back to lightweight manual checks otherwise so validation always runs. Catching
bad data here prevents it from silently corrupting training or inference.
"""
from __future__ import annotations

import pandas as pd

from src.config import CONFIG
from src.utils.logging import get_logger

logger = get_logger("validation")

# Plausible ranges for numeric fields (None = unbounded on that side).
_RANGES = {
    "age": (18, 100),
    "annual_income": (0, 2_000_000),
    "bmi": (10, 70),
    "num_dependents": (0, 20),
    "prior_claims_count": (0, 50),
    "years_as_customer": (0, 60),
    "credit_score": (300, 850),
    "chronic_conditions": (0, 20),
}
_ALLOWED = {
    "sex": {"male", "female", "other"},
    "smoker": {"yes", "no"},
    "occupation_risk": {"low", "medium", "high"},
    "exercise_frequency": {"never", "occasional", "regular"},
    "region": {"northeast", "southeast", "midwest", "west"},
}


def validate(df: pd.DataFrame, *, require_target: bool = True) -> pd.DataFrame:
    """Validate a dataframe of applicants. Raises ValueError on hard failures."""
    feats = CONFIG.features
    required = list(feats.numeric) + list(feats.categorical)
    if require_target:
        required.append(CONFIG.target)

    missing_cols = [c for c in required if c not in df.columns]
    if missing_cols:
        raise ValueError(f"Missing required columns: {missing_cols}")

    errors: list[str] = []
    for col, (lo, hi) in _RANGES.items():
        if col not in df.columns:
            continue
        s = pd.to_numeric(df[col], errors="coerce")
        bad = s.dropna()[(s.dropna() < lo) | (s.dropna() > hi)]
        if len(bad):
            errors.append(f"'{col}': {len(bad)} value(s) outside [{lo}, {hi}]")

    for col, allowed in _ALLOWED.items():
        if col not in df.columns:
            continue
        seen = set(df[col].dropna().unique())
        unexpected = seen - allowed
        if unexpected:
            errors.append(f"'{col}': unexpected categories {sorted(unexpected)}")

    if errors:
        raise ValueError("Data validation failed:\n  - " + "\n  - ".join(errors))

    logger.info("Validation passed (%d rows, %d columns).", len(df), df.shape[1])
    return df
