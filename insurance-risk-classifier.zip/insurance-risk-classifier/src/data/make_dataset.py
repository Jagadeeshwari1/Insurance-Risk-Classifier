"""Generate a synthetic insurance underwriting dataset.

The label ``claim`` (1 = significant claim / loss in the policy period) is drawn
from a logistic function of *legitimate* risk drivers (age, smoking, BMI,
chronic conditions, prior claims, occupation risk) plus noise. ``sex`` is NOT a
direct driver of the label, which makes the downstream fairness analysis
meaningful: any disparity the model shows comes from correlated features, not
from the label being unfair by construction.

Run:  python -m src.data.make_dataset --n 20000
"""
from __future__ import annotations

import argparse

import numpy as np
import pandas as pd

from src.config import CONFIG
from src.utils.logging import get_logger

logger = get_logger("make_dataset")

REGIONS = ["northeast", "southeast", "midwest", "west"]
OCCUPATION_RISK = ["low", "medium", "high"]
EXERCISE = ["never", "occasional", "regular"]


def _sigmoid(x: np.ndarray) -> np.ndarray:
    return 1.0 / (1.0 + np.exp(-x))


def generate(n: int = 20_000, seed: int = 42) -> pd.DataFrame:
    """Create ``n`` synthetic applicants with a learnable claim label."""
    rng = np.random.default_rng(seed)

    sex = rng.choice(["male", "female"], size=n, p=[0.5, 0.5])
    age = np.clip(rng.normal(45, 15, n), 18, 85).round().astype(int)
    annual_income = np.clip(rng.lognormal(10.9, 0.5, n), 12_000, 500_000).round(-2)
    bmi = np.clip(rng.normal(27, 5, n), 15, 55).round(1)

    # Smoking correlates mildly with sex + occupation -> realistic confounding.
    smoke_logit = -1.4 + 0.25 * (sex == "male") + 0.02 * (age - 45)
    smoker = np.where(rng.random(n) < _sigmoid(smoke_logit), "yes", "no")

    num_dependents = rng.poisson(1.1, n).clip(0, 8)
    prior_claims_count = rng.poisson(0.6, n).clip(0, 12)
    years_as_customer = np.clip(rng.exponential(4, n), 0, 30).round(1)
    credit_score = np.clip(rng.normal(690, 70, n), 300, 850).round().astype(int)
    occupation_risk = rng.choice(OCCUPATION_RISK, size=n, p=[0.55, 0.30, 0.15])
    chronic_conditions = rng.poisson(0.5 + 0.03 * (age - 45).clip(0), n).clip(0, 6)
    exercise = rng.choice(EXERCISE, size=n, p=[0.35, 0.40, 0.25])
    region = rng.choice(REGIONS, size=n)

    # ----- Risk model (ground truth) — legitimate drivers only -----
    occ_w = np.select(
        [occupation_risk == "low", occupation_risk == "medium"],
        [0.0, 0.5], default=1.1,
    )
    ex_w = np.select(
        [exercise == "regular", exercise == "occasional"],
        [-0.4, 0.0], default=0.4,
    )
    logit = (
        -3.2
        + 0.030 * (age - 45)
        + 1.30 * (smoker == "yes")
        + 0.055 * (bmi - 27)
        + 0.45 * chronic_conditions
        + 0.40 * prior_claims_count
        + occ_w
        + ex_w
        - 0.0020 * (credit_score - 690)
        - 0.04 * years_as_customer
    )
    logit += rng.normal(0, 0.5, n)  # irreducible noise
    prob = _sigmoid(logit)
    claim = (rng.random(n) < prob).astype(int)

    df = pd.DataFrame(
        {
            "applicant_id": [f"APP{100000 + i}" for i in range(n)],
            "age": age,
            "sex": sex,
            "annual_income": annual_income,
            "bmi": bmi,
            "smoker": smoker,
            "region": region,
            "num_dependents": num_dependents,
            "prior_claims_count": prior_claims_count,
            "years_as_customer": years_as_customer,
            "credit_score": credit_score,
            "occupation_risk": occupation_risk,
            "chronic_conditions": chronic_conditions,
            "exercise_frequency": exercise,
            "claim": claim,
        }
    )

    # Inject a little realistic missingness.
    for col, frac in {"bmi": 0.03, "credit_score": 0.02, "annual_income": 0.01}.items():
        mask = rng.random(n) < frac
        df.loc[mask, col] = np.nan

    return df


def main() -> None:
    parser = argparse.ArgumentParser(description="Generate synthetic insurance data")
    parser.add_argument("--n", type=int, default=20_000, help="number of rows")
    parser.add_argument("--seed", type=int, default=CONFIG.random_seed)
    args = parser.parse_args()

    df = generate(n=args.n, seed=args.seed)
    out = CONFIG.path("raw_data")
    out.parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(out, index=False)
    rate = df[CONFIG.target].mean()
    logger.info("Wrote %d rows to %s (claim rate = %.1f%%)", len(df), out, 100 * rate)


if __name__ == "__main__":
    main()
