"""Explainability.

Adverse-action notices and regulatory review require a per-decision reason
("why was this applicant rated high-risk"). When SHAP is installed we use it for
both global and per-instance attributions, with a stored background sample as
the reference distribution. Otherwise we fall back to permutation importance
(global) and a transparent leave-one-out proxy (per-instance), so explanations
are always available regardless of environment.
"""
from __future__ import annotations

import importlib.util

import numpy as np
import pandas as pd

from src.utils.logging import get_logger

logger = get_logger("explain")

_HAS_SHAP = importlib.util.find_spec("shap") is not None


def _binary_shap_values(arr: np.ndarray) -> np.ndarray:
    """Reduce SHAP output to the positive-class contribution array."""
    if arr.ndim == 3:  # (n, features, classes)
        return arr[:, :, 1]
    return arr


def global_importance(
    fitted_model, X_sample: pd.DataFrame, y_sample=None
) -> list[dict]:
    """Return features ranked by global importance (top 15)."""
    if _HAS_SHAP:
        try:
            import shap

            background = X_sample.sample(
                min(200, len(X_sample)), random_state=42
            )
            explainer = shap.Explainer(fitted_model.predict_proba, background)
            values = explainer(X_sample[: min(500, len(X_sample))])
            mean_abs = np.abs(_binary_shap_values(values.values)).mean(axis=0)
            ranked = sorted(
                zip(X_sample.columns, mean_abs), key=lambda x: x[1], reverse=True
            )
            return [{"feature": f, "importance": float(v)} for f, v in ranked[:15]]
        except Exception as exc:  # pragma: no cover - shap can be finicky
            logger.warning("SHAP global failed (%s); using permutation.", exc)

    if y_sample is None:
        return [{"feature": c, "importance": None} for c in X_sample.columns[:15]]

    from sklearn.inspection import permutation_importance

    result = permutation_importance(
        fitted_model, X_sample, y_sample, n_repeats=5, random_state=42, n_jobs=-1
    )
    ranked = sorted(
        zip(X_sample.columns, result.importances_mean),
        key=lambda x: x[1],
        reverse=True,
    )
    return [{"feature": f, "importance": float(v)} for f, v in ranked[:15]]


def explain_instance(
    fitted_model,
    x_row: pd.DataFrame,
    background: pd.DataFrame,
    top_k: int = 5,
) -> list[dict]:
    """Top factors pushing a single (raw, unprocessed) prediction up or down.

    ``background`` is a sample of raw training rows used as the reference
    distribution. With SHAP these are true Shapley contributions; without it, a
    leave-one-out perturbation toward the reference median/mode that is
    directionally honest and model-agnostic.
    """
    if _HAS_SHAP:
        try:
            import shap

            bg = background.sample(min(100, len(background)), random_state=42)
            explainer = shap.Explainer(fitted_model.predict_proba, bg)
            sv = explainer(x_row)
            contribs = _binary_shap_values(sv.values)[0]
            order = np.argsort(np.abs(contribs))[::-1][:top_k]
            return [_factor(x_row, i, float(contribs[i])) for i in order]
        except Exception as exc:  # pragma: no cover
            logger.warning("SHAP instance failed (%s); using proxy.", exc)

    base = float(fitted_model.predict_proba(x_row)[0, 1])
    results = []
    for col in x_row.columns:
        perturbed = x_row.copy()
        if col in background.columns and pd.api.types.is_numeric_dtype(background[col]):
            perturbed[col] = background[col].median()
        elif col in background.columns:
            mode = background[col].mode()
            perturbed[col] = mode.iloc[0] if len(mode) else x_row.iloc[0][col]
        delta = base - float(fitted_model.predict_proba(perturbed)[0, 1])
        results.append((col, delta))

    results.sort(key=lambda x: abs(x[1]), reverse=True)
    idx_of = {c: list(x_row.columns).index(c) for c, _ in results[:top_k]}
    return [_factor(x_row, idx_of[c], d) for c, d in results[:top_k]]


def _factor(x_row: pd.DataFrame, i: int, contribution: float) -> dict:
    return {
        "feature": x_row.columns[i],
        "value": _scalar(x_row.iloc[0, i]),
        "contribution": contribution,
        "direction": "increases_risk" if contribution > 0 else "decreases_risk",
    }


def _scalar(v):
    if isinstance(v, np.generic):
        return v.item()
    if pd.isna(v):
        return None
    return v
