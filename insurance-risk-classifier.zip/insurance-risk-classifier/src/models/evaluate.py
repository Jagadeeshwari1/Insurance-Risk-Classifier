"""Model evaluation for insurance risk.

Three groups of metrics:
  1. Discrimination — ROC-AUC, PR-AUC, plus a classification report at the
     operating threshold.
  2. Calibration — Brier score + a reliability table. Underwriting prices off a
     *true* probability, so calibration matters as much as ranking.
  3. Fairness — group-wise selection/error rates and the four-fifths
     disparate-impact ratio across protected attributes.
"""
from __future__ import annotations

import numpy as np
import pandas as pd
from sklearn.metrics import (
    average_precision_score,
    brier_score_loss,
    classification_report,
    confusion_matrix,
    roc_auc_score,
)

from src.config import CONFIG
from src.utils.logging import get_logger

logger = get_logger("evaluate")


def discrimination_metrics(y_true, y_prob, threshold: float) -> dict:
    y_pred = (np.asarray(y_prob) >= threshold).astype(int)
    tn, fp, fn, tp = confusion_matrix(y_true, y_pred).ravel()
    report = classification_report(y_true, y_pred, output_dict=True, zero_division=0)
    return {
        "roc_auc": float(roc_auc_score(y_true, y_prob)),
        "pr_auc": float(average_precision_score(y_true, y_prob)),
        "threshold": float(threshold),
        "precision": float(report["1"]["precision"]),
        "recall": float(report["1"]["recall"]),
        "f1": float(report["1"]["f1-score"]),
        "confusion_matrix": {"tn": int(tn), "fp": int(fp), "fn": int(fn), "tp": int(tp)},
    }


def calibration_metrics(y_true, y_prob, n_bins: int = 10) -> dict:
    """Brier score + reliability table (mean predicted vs observed per bin)."""
    y_true = np.asarray(y_true)
    y_prob = np.asarray(y_prob)
    bins = np.linspace(0, 1, n_bins + 1)
    idx = np.clip(np.digitize(y_prob, bins) - 1, 0, n_bins - 1)
    table = []
    for b in range(n_bins):
        mask = idx == b
        if mask.sum() == 0:
            continue
        table.append(
            {
                "bin": f"[{bins[b]:.1f}, {bins[b + 1]:.1f})",
                "count": int(mask.sum()),
                "mean_predicted": float(y_prob[mask].mean()),
                "observed_rate": float(y_true[mask].mean()),
            }
        )
    return {
        "brier_score": float(brier_score_loss(y_true, y_prob)),
        "reliability_table": table,
    }


def fairness_metrics(
    y_true, y_prob, groups: pd.Series, threshold: float
) -> dict:
    """Group-wise rates and the disparate-impact (four-fifths) ratio.

    Reports selection rate (flagged high-risk), TPR and FPR per group, then the
    ratio of the lowest to highest selection rate. A ratio < 0.8 is the classic
    adverse-impact flag.
    """
    y_true = np.asarray(y_true)
    y_pred = (np.asarray(y_prob) >= threshold).astype(int)
    groups = pd.Series(groups).reset_index(drop=True)

    per_group = {}
    selection_rates = {}
    for g in sorted(groups.dropna().unique()):
        m = (groups == g).to_numpy()
        gt, gp = y_true[m], y_pred[m]
        pos = gt == 1
        neg = gt == 0
        sel = float(gp.mean())
        per_group[str(g)] = {
            "n": int(m.sum()),
            "base_rate": float(gt.mean()),
            "selection_rate": sel,
            "tpr": float(gp[pos].mean()) if pos.any() else None,
            "fpr": float(gp[neg].mean()) if neg.any() else None,
        }
        selection_rates[str(g)] = sel

    di_ratio = None
    rate_gap = None
    if len(selection_rates) >= 2:
        hi, lo = max(selection_rates.values()), min(selection_rates.values())
        di_ratio = float(lo / hi) if hi > 0 else None
        rate_gap = float(hi - lo)

    flagged = (
        di_ratio is not None
        and di_ratio < CONFIG.fairness.min_disparate_impact_ratio
    )
    return {
        "per_group": per_group,
        "disparate_impact_ratio": di_ratio,
        "selection_rate_gap": rate_gap,
        "adverse_impact_flag": bool(flagged),
    }


def evaluate_all(y_true, y_prob, protected: pd.DataFrame | None = None) -> dict:
    threshold = CONFIG.decision_threshold
    out = {
        "discrimination": discrimination_metrics(y_true, y_prob, threshold),
        "calibration": calibration_metrics(y_true, y_prob),
    }
    if protected is not None:
        out["fairness"] = {
            col: fairness_metrics(y_true, y_prob, protected[col], threshold)
            for col in protected.columns
        }
    logger.info(
        "ROC-AUC=%.3f  PR-AUC=%.3f  Brier=%.4f",
        out["discrimination"]["roc_auc"],
        out["discrimination"]["pr_auc"],
        out["calibration"]["brier_score"],
    )
    return out
