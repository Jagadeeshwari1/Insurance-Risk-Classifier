"""Inference helpers shared by the API and CLI.

A trained artifact is a *bundle* (joblib) holding the fitted pipeline, the
feature schema, the probability->tier thresholds, a background sample for
explanations, and metadata. ``predict_one`` returns the calibrated probability,
the risk tier, and the top contributing factors.
"""
from __future__ import annotations

from functools import lru_cache
from pathlib import Path
from typing import Any

import joblib
import pandas as pd

from src.config import CONFIG
from src.models.explain import explain_instance
from src.utils.logging import get_logger

logger = get_logger("predict")


def probability_to_tier(prob: float) -> str:
    """Map a calibrated P(claim) to a risk tier using config thresholds."""
    tiers = CONFIG.risk_tiers
    if prob < tiers["low"]:
        return "low"
    if prob < tiers["medium"]:
        return "medium"
    return "high"


@lru_cache(maxsize=1)
def load_bundle(path: str | None = None) -> dict[str, Any]:
    """Load (and cache) the model bundle from disk."""
    p = Path(path) if path else CONFIG.path("model_file")
    if not p.exists():
        raise FileNotFoundError(
            f"No model at {p}. Train first: `python -m src.models.train`."
        )
    bundle = joblib.load(p)
    logger.info("Loaded model bundle (backend=%s).", bundle.get("backend"))
    return bundle


def _to_frame(payload: dict | pd.DataFrame) -> pd.DataFrame:
    if isinstance(payload, pd.DataFrame):
        return payload.reset_index(drop=True)
    return pd.DataFrame([payload])


def predict_one(payload: dict, *, explain: bool = True, bundle=None) -> dict:
    """Score a single applicant. ``payload`` is a dict of raw feature values."""
    bundle = bundle or load_bundle()
    model = bundle["pipeline"]
    feature_cols = bundle["feature_columns"]

    X = _to_frame(payload)
    missing = [c for c in feature_cols if c not in X.columns]
    if missing:
        raise ValueError(f"Missing features: {missing}")
    X = X[feature_cols]

    prob = float(model.predict_proba(X)[0, 1])
    result = {
        "probability": round(prob, 4),
        "risk_tier": probability_to_tier(prob),
        "decision_threshold": CONFIG.decision_threshold,
        "flagged_high_risk": prob >= CONFIG.decision_threshold,
        "model_version": bundle.get("version"),
    }
    if explain:
        result["top_factors"] = explain_instance(
            model, X, bundle["background"], top_k=5
        )
    return result


def predict_batch(payloads: list[dict], *, explain: bool = False) -> list[dict]:
    bundle = load_bundle()
    return [predict_one(p, explain=explain, bundle=bundle) for p in payloads]
