"""Model factory.

Returns the best gradient-boosting classifier available in the environment,
following the preference order in config. Falls back to scikit-learn's
``HistGradientBoostingClassifier`` so the pipeline trains anywhere. Class
imbalance (high-risk cases are rare) is handled per-library.
"""
from __future__ import annotations

from typing import Any

from src.config import CONFIG
from src.utils.logging import get_logger

logger = get_logger("model_factory")


def _importlib_available(name: str) -> bool:
    import importlib.util

    return importlib.util.find_spec(name) is not None


def build_model(pos_weight: float = 1.0) -> tuple[Any, str]:
    """Return (estimator, backend_name).

    ``pos_weight`` = (# negatives / # positives), used to counter imbalance.
    """
    params = CONFIG.model.params
    seed = CONFIG.random_seed

    for backend in CONFIG.model.preference:
        if backend == "xgboost" and _importlib_available("xgboost"):
            from xgboost import XGBClassifier

            model = XGBClassifier(
                n_estimators=params["n_estimators"],
                max_depth=params["max_depth"],
                learning_rate=params["learning_rate"],
                scale_pos_weight=pos_weight,
                eval_metric="logloss",
                tree_method="hist",
                random_state=seed,
                n_jobs=-1,
            )
            logger.info("Using XGBoost (scale_pos_weight=%.2f).", pos_weight)
            return model, "xgboost"

        if backend == "lightgbm" and _importlib_available("lightgbm"):
            from lightgbm import LGBMClassifier

            model = LGBMClassifier(
                n_estimators=params["n_estimators"],
                max_depth=params["max_depth"],
                learning_rate=params["learning_rate"],
                class_weight="balanced",
                random_state=seed,
                n_jobs=-1,
                verbose=-1,
            )
            logger.info("Using LightGBM (class_weight=balanced).")
            return model, "lightgbm"

        if backend == "catboost" and _importlib_available("catboost"):
            from catboost import CatBoostClassifier

            model = CatBoostClassifier(
                iterations=params["n_estimators"],
                depth=params["max_depth"],
                learning_rate=params["learning_rate"],
                auto_class_weights="Balanced",
                random_seed=seed,
                verbose=False,
            )
            logger.info("Using CatBoost (auto_class_weights=Balanced).")
            return model, "catboost"

        if backend == "sklearn":
            from sklearn.ensemble import HistGradientBoostingClassifier

            model = HistGradientBoostingClassifier(
                max_iter=params["n_estimators"],
                max_depth=params["max_depth"],
                learning_rate=params["learning_rate"],
                class_weight="balanced",
                random_state=seed,
            )
            logger.info("Using scikit-learn HistGradientBoosting (class_weight=balanced).")
            return model, "sklearn-histgbm"

    raise RuntimeError("No suitable model backend found.")
