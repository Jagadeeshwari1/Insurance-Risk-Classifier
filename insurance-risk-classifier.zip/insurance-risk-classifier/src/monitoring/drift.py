"""Input drift monitoring via Population Stability Index (PSI).

PSI is the standard drift metric in insurance and credit scoring. It compares a
baseline (training) distribution against a current (production) distribution per
feature. Rule of thumb: PSI < 0.10 stable, 0.10-0.25 moderate shift, > 0.25
significant shift (retrain/investigate). Evidently AI is the richer production
choice; this dependency-free version runs anywhere.

Run:  python -m src.monitoring.drift --current path/to/recent.csv
"""
from __future__ import annotations

import argparse

import numpy as np
import pandas as pd

from src.config import CONFIG
from src.features.build_features import get_feature_lists
from src.utils.logging import get_logger

logger = get_logger("drift")


def _psi_numeric(expected: pd.Series, actual: pd.Series, bins: int = 10) -> float:
    expected = expected.dropna()
    actual = actual.dropna()
    quantiles = np.unique(np.quantile(expected, np.linspace(0, 1, bins + 1)))
    if len(quantiles) < 2:
        return 0.0
    e_counts, _ = np.histogram(expected, bins=quantiles)
    a_counts, _ = np.histogram(actual, bins=quantiles)
    return _psi_from_counts(e_counts, a_counts)


def _psi_categorical(expected: pd.Series, actual: pd.Series) -> float:
    cats = sorted(set(expected.dropna().unique()) | set(actual.dropna().unique()))
    e_counts = expected.value_counts().reindex(cats).fillna(0).to_numpy()
    a_counts = actual.value_counts().reindex(cats).fillna(0).to_numpy()
    return _psi_from_counts(e_counts, a_counts)


def _psi_from_counts(e_counts, a_counts) -> float:
    e = e_counts / max(e_counts.sum(), 1)
    a = a_counts / max(a_counts.sum(), 1)
    eps = 1e-6
    e = np.clip(e, eps, None)
    a = np.clip(a, eps, None)
    return float(np.sum((a - e) * np.log(a / e)))


def compute_drift(baseline: pd.DataFrame, current: pd.DataFrame) -> dict:
    numeric, categorical = get_feature_lists()
    warn, alert = CONFIG.monitoring.psi_warn, CONFIG.monitoring.psi_alert
    report = {}
    for col in numeric:
        if col in baseline and col in current:
            report[col] = _label(_psi_numeric(baseline[col], current[col]), warn, alert)
    for col in categorical:
        if col in baseline and col in current:
            report[col] = _label(_psi_categorical(baseline[col], current[col]), warn, alert)
    n_alert = sum(1 for v in report.values() if v["status"] == "alert")
    return {"features": report, "alerts": n_alert, "overall": "alert" if n_alert else "ok"}


def _label(psi: float, warn: float, alert: float) -> dict:
    status = "alert" if psi >= alert else "warn" if psi >= warn else "ok"
    return {"psi": round(psi, 4), "status": status}


def main() -> None:
    parser = argparse.ArgumentParser(description="Compute input drift (PSI)")
    parser.add_argument("--current", required=True, help="CSV of recent production data")
    parser.add_argument("--baseline", default=str(CONFIG.path("raw_data")))
    args = parser.parse_args()

    baseline = pd.read_csv(args.baseline)
    current = pd.read_csv(args.current)
    report = compute_drift(baseline, current)
    for col, v in report["features"].items():
        flag = "" if v["status"] == "ok" else f"  <-- {v['status'].upper()}"
        logger.info("PSI %-22s %.4f%s", col, v["psi"], flag)
    logger.info("Overall drift status: %s (%d alerts)", report["overall"], report["alerts"])


if __name__ == "__main__":
    main()
