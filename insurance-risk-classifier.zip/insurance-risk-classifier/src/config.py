"""Configuration loader.

Reads ``config/config.yaml`` when PyYAML is available; otherwise returns an
equivalent set of built-in defaults. Keeping a code-level fallback means the
whole pipeline runs in a minimal environment (pandas + scikit-learn only).
"""
from __future__ import annotations

from pathlib import Path
from typing import Any

# Project root = two levels up from this file (src/config.py -> repo root).
ROOT = Path(__file__).resolve().parents[1]
CONFIG_PATH = ROOT / "config" / "config.yaml"

# Built-in defaults — kept in sync with config/config.yaml. Used as a fallback
# when PyYAML or the YAML file is missing.
_DEFAULTS: dict[str, Any] = {
    "project_name": "insurance-risk-classifier",
    "random_seed": 42,
    "paths": {
        "raw_data": "data/raw/applications.csv",
        "processed_data": "data/processed/",
        "model_dir": "models/",
        "model_file": "models/risk_model.joblib",
        "metrics_file": "models/metrics.json",
        "model_card": "models/MODEL_CARD.md",
    },
    "target": "claim",
    "features": {
        "numeric": [
            "age", "annual_income", "bmi", "num_dependents",
            "prior_claims_count", "years_as_customer", "credit_score",
            "chronic_conditions",
        ],
        "categorical": [
            "sex", "region", "smoker", "occupation_risk", "exercise_frequency",
        ],
        "protected": ["sex"],
        "drop": ["applicant_id"],
    },
    "risk_tiers": {"low": 0.15, "medium": 0.40, "high": 1.01},
    "decision_threshold": 0.40,
    "model": {
        "preference": ["xgboost", "lightgbm", "catboost", "sklearn"],
        "calibration_method": "isotonic",
        "calibration_cv": 3,
        "test_size": 0.2,
        "params": {"n_estimators": 300, "max_depth": 5, "learning_rate": 0.05},
    },
    "fairness": {"max_rate_gap": 0.10, "min_disparate_impact_ratio": 0.80},
    "monitoring": {"psi_warn": 0.10, "psi_alert": 0.25},
}


class Config(dict):
    """Dict subclass with attribute access and absolute-path resolution."""

    def __getattr__(self, name: str) -> Any:
        try:
            value = self[name]
        except KeyError as exc:  # pragma: no cover - defensive
            raise AttributeError(name) from exc
        return Config(value) if isinstance(value, dict) else value

    def path(self, key: str) -> Path:
        """Resolve a key under ``paths`` to an absolute path under the repo root."""
        return ROOT / self["paths"][key]


def load_config() -> Config:
    """Load configuration, preferring config.yaml and falling back to defaults."""
    data = dict(_DEFAULTS)
    try:
        import yaml  # type: ignore

        if CONFIG_PATH.exists():
            with open(CONFIG_PATH, "r", encoding="utf-8") as fh:
                loaded = yaml.safe_load(fh) or {}
            data = _deep_merge(data, loaded)
    except ImportError:
        # PyYAML not installed — defaults already cover everything.
        pass
    return Config(data)


def _deep_merge(base: dict, override: dict) -> dict:
    """Recursively merge ``override`` into ``base`` (override wins)."""
    out = dict(base)
    for key, value in override.items():
        if isinstance(value, dict) and isinstance(out.get(key), dict):
            out[key] = _deep_merge(out[key], value)
        else:
            out[key] = value
    return out


CONFIG = load_config()
