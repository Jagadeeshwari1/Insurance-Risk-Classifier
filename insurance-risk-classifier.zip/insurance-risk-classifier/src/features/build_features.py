"""Feature engineering.

Builds a scikit-learn ``ColumnTransformer`` that is reused *identically* at
training and inference time — this is the single most important guard against
train/serve skew. Protected attributes are excluded from model inputs here.
"""
from __future__ import annotations

from sklearn.compose import ColumnTransformer
from sklearn.impute import SimpleImputer
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler

from src.config import CONFIG


def get_feature_lists() -> tuple[list[str], list[str]]:
    """Return (numeric, categorical) feature names, excluding protected ones."""
    feats = CONFIG.features
    protected = set(feats.protected)
    numeric = [c for c in feats.numeric if c not in protected]
    categorical = [c for c in feats.categorical if c not in protected]
    return numeric, categorical


def build_preprocessor() -> ColumnTransformer:
    """Numeric: median-impute + scale. Categorical: mode-impute + one-hot."""
    numeric, categorical = get_feature_lists()

    numeric_pipe = Pipeline(
        steps=[
            ("impute", SimpleImputer(strategy="median")),
            ("scale", StandardScaler()),
        ]
    )
    categorical_pipe = Pipeline(
        steps=[
            ("impute", SimpleImputer(strategy="most_frequent")),
            ("onehot", OneHotEncoder(handle_unknown="ignore", sparse_output=False)),
        ]
    )

    return ColumnTransformer(
        transformers=[
            ("num", numeric_pipe, numeric),
            ("cat", categorical_pipe, categorical),
        ],
        remainder="drop",
        verbose_feature_names_out=False,
    )
