"""Test suite. Run: pytest -q

API tests skip automatically if FastAPI/pydantic aren't installed, so the core
data-science tests still run in a minimal environment.
"""
from __future__ import annotations

import importlib.util

import pandas as pd
import pytest

from src.data.make_dataset import generate
from src.data.validation import validate
from src.features.build_features import build_preprocessor, get_feature_lists
from src.models.evaluate import fairness_metrics
from src.monitoring.drift import compute_drift


@pytest.fixture(scope="module")
def sample_df() -> pd.DataFrame:
    return generate(n=2000, seed=7)


def test_generate_has_signal(sample_df):
    assert len(sample_df) == 2000
    rate = sample_df["claim"].mean()
    assert 0.05 < rate < 0.5  # imbalanced but learnable


def test_validation_passes(sample_df):
    validate(sample_df)


def test_validation_catches_bad_range(sample_df):
    bad = sample_df.copy()
    bad.loc[0, "age"] = 500
    with pytest.raises(ValueError):
        validate(bad)


def test_preprocessor_excludes_protected(sample_df):
    numeric, categorical = get_feature_lists()
    assert "sex" not in numeric and "sex" not in categorical
    pre = build_preprocessor()
    X = pre.fit_transform(sample_df[numeric + categorical])
    assert X.shape[0] == len(sample_df)
    assert X.shape[1] > 0


def test_fairness_ratio_in_range(sample_df):
    y = sample_df["claim"].to_numpy()
    # Random scores -> roughly equal selection across groups.
    import numpy as np

    rng = np.random.default_rng(0)
    prob = rng.random(len(sample_df))
    fm = fairness_metrics(y, prob, sample_df["sex"], threshold=0.5)
    assert 0.0 <= fm["disparate_impact_ratio"] <= 1.0


def test_drift_zero_for_identical(sample_df):
    report = compute_drift(sample_df, sample_df)
    assert report["overall"] == "ok"
    assert all(v["psi"] < 0.01 for v in report["features"].values())


@pytest.mark.skipif(
    importlib.util.find_spec("fastapi") is None,
    reason="fastapi not installed",
)
def test_api_health():
    from fastapi.testclient import TestClient

    from api.main import app

    client = TestClient(app)
    resp = client.get("/health")
    assert resp.status_code == 200
    assert resp.json()["status"] == "ok"
